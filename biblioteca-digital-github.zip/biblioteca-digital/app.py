import customtkinter as ctk
from tkinter import messagebox

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

livros = []

app = ctk.CTk()
app.title("Biblioteca Digital")
app.geometry("750x650")

titulo = ctk.CTkLabel(
    app,
    text="BIBLIOTECA DIGITAL",
    font=("Arial", 26, "bold")
)
titulo.pack(pady=20)

entrada_titulo = ctk.CTkEntry(
    app, placeholder_text="Título do livro", width=350
)
entrada_titulo.pack(pady=8)

entrada_autor = ctk.CTkEntry(
    app, placeholder_text="Nome do autor", width=350
)
entrada_autor.pack(pady=8)

entrada_categoria = ctk.CTkEntry(
    app, placeholder_text="Categoria", width=350
)
entrada_categoria.pack(pady=8)

lista = ctk.CTkTextbox(app, width=550, height=250)
lista.pack(pady=15)


def atualizar_lista():
    lista.delete("1.0", "end")
    for livro in livros:
        lista.insert(
            "end",
            f"{livro['titulo']} - {livro['autor']} - "
            f"{livro['categoria']} - {livro['status']}\n"
        )


def cadastrar():
    nome = entrada_titulo.get().strip()
    autor = entrada_autor.get().strip()
    categoria = entrada_categoria.get().strip()

    if not nome or not autor or not categoria:
        messagebox.showwarning("Aviso", "Preencha todos os campos!")
        return

    livros.append({
        "titulo": nome,
        "autor": autor,
        "categoria": categoria,
        "status": "Disponível"
    })

    atualizar_lista()
    entrada_titulo.delete(0, "end")
    entrada_autor.delete(0, "end")
    entrada_categoria.delete(0, "end")
    messagebox.showinfo("Sucesso", "Livro cadastrado!")


def pesquisar():
    nome = entrada_titulo.get().strip().lower()

    if not nome:
        messagebox.showwarning(
            "Aviso", "Digite um título no campo de pesquisa."
        )
        return

    resultados = [
        livro for livro in livros
        if nome in livro["titulo"].lower()
    ]

    lista.delete("1.0", "end")

    if not resultados:
        lista.insert("end", "Nenhum livro encontrado.\n")
        return

    for livro in resultados:
        lista.insert(
            "end",
            f"{livro['titulo']} - {livro['autor']} - "
            f"{livro['categoria']} - {livro['status']}\n"
        )


botao_cadastrar = ctk.CTkButton(
    app, text="Cadastrar Livro", command=cadastrar
)
botao_cadastrar.pack(pady=5)

botao_pesquisar = ctk.CTkButton(
    app, text="Pesquisar Livro", command=pesquisar
)
botao_pesquisar.pack(pady=5)

botao_listar = ctk.CTkButton(
    app, text="Mostrar Todos", command=atualizar_lista
)
botao_listar.pack(pady=5)

app.mainloop()
